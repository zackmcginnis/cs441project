@XmlAccessorType(XmlAccessType.FIELD)
@XmlSchema(namespace = "http://www.cspoker.org/api/2008-11/")
package bots.mctsbot.common.api.lobby.holdemtable.holdemplayer.event;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchema;

