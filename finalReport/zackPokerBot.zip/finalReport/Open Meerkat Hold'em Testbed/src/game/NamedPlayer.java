package game;

import com.biotools.meerkat.Player;

public interface NamedPlayer extends Player {

	void setIngameName(String name);

}
