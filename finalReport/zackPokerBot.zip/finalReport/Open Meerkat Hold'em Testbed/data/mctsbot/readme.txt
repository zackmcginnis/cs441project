MCTSBot will place its learned opponent-actions here.
Make sure to empty the directory if you want to start 'clean'